
	The PIZZA MANIA specialized in custom made pizzas is currently taking orders by phone. The current system where the customer calls the pizzeria takes time of employees to answer the phone and is more work consuming than necessary. We want to allow customers to customize and order their pizzas online. The pizzeria also aims to increase the sales, due to the easy to use order online website. The system will give the employees more time to “work” rather then to
accept orders by phone, also the potential increase in customers are enough reason for the pizzeria to accept the change (website where customers can order their customized pizzas).

Core Functionalities of Projects:
The main 3 functionalities of the project are listed down as follows:

1.Ordering:
Ordering involves customizing pizzas, selecting products and entering customer information. The system will have to provide the user with data about the ingredients and the non-pizza products such as name and price. Users will provide an order which consists of pizzas, non-pizza products, and customer information like name, address and telephone number. For every custom pizza and non-pizza product users can also specify an amount if they wish to order more than one of them.

2.Order processing:
Order processing is involved in preparing and delivering orders. The system needs to provide the kitchen employees with a list of pending orders. Of each order the ordered products and pizzas must be shown, together with the amount of each product. The kitchen employees will first view the order and decide if they are going to process the order or not. The decision will be entered by changing the status of the order to the respective status. After the order is prepared, the order will be passed to the delivery employees who will use the system to retrieve the customer details.. The status of the order will change to
“being delivered” and an new e-mail will be sent to the customer. When the order is delivered, the delivery employee can mark the order as “delivered”, or in case he failed to deliver it he will make it as “failed to deliver”.

3.Administration:
Administration includes adding, editing and deleting available ingredients, non-pizza products and employees and viewing previous orders. The system will be able to show a list of ingredients and a list of products. For each ingredient and non-pizza product a name, price and picture can be specified. The system also needs a function to show previous orders.

A web based interface for ordering pizza online is developed, which makes users to see order their favourite pizzas easily. User can register to the site and then can easily place the orders. The site is user-friendly and also has other non pizza products.
Future enhancement:
The existing system can be enhanced, by providing the online payment gateway. Also we need to add the sms service for the users.


